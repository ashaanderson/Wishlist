package com.example.wishlist;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class adapterfile  extends RecyclerView.Adapter<adapterfile.CustomViewHolder> {

    List<datafile> datafile;

    public adapterfile(List<datafile> datafile) {
        this.datafile = datafile;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.custom_layout,parent,false);
        CustomViewHolder cus = new CustomViewHolder(view);
        return cus;
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, int position) {
        holder.nameText.setText(datafile.get(position).getName());
        holder.priceText.setText(datafile.get(position).getPrice());
        holder.urlText.setText(datafile.get(position).getUrl());
    }

    @Override
    public int getItemCount() {
        return datafile.size();
    }

    public static class CustomViewHolder extends RecyclerView.ViewHolder{
        TextView nameText, priceText, urlText;

        public CustomViewHolder(@NonNull View itemView) {
            super(itemView);
            nameText = itemView.findViewById(R.id.nameText);
            priceText = itemView.findViewById(R.id.priceText);
            urlText = itemView.findViewById(R.id.urlText);
        }
    }
}