package com.example.wishlist;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recView;
    private List<datafile> datafile;
    EditText e_name, e_price, e_url;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e_name = findViewById(R.id.name);
        e_price = findViewById(R.id.price);
        e_url = findViewById(R.id.url);
        submit = findViewById(R.id.submit);
        datafile = new ArrayList<>();

        recView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recView.setLayoutManager(linearLayoutManager);

        adapterfile adapter = new adapterfile(datafile);
        recView.setAdapter(adapter);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = e_name.getText().toString();
                String price = e_price.getText().toString();
                String url = e_url.getText().toString();
                datafile mUserData = new datafile(name,price,url);
                datafile.add(mUserData);
                adapter.notifyDataSetChanged();
                clearFields();
            }
        });



    }
    public void clearFields(){
        e_name.setText("");
        e_price.setText("");
        e_url.setText("");
    }
}
